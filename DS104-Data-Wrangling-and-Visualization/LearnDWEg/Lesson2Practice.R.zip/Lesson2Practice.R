library("readxl")
tea <- read_excel("Documents/GitHub/DS-Student-Resources/DS104-Data-Wrangling-and-Visualization/LearnDWEg/tea.xlsx")
View(tea)

#Rows to columns
tea_transposed <- t(tea)
View(tea_transposed)

class(tea_transposed)

# turn into a data frame using the function as.data.frame():

tea1 <- as.data.frame(tea_transposed)
View(tea1)

#to rename them, 
#you could use the gsub() function within the names() function to do so. 

names(tea1) <- gsub("V", "Year", names(tea1))



## Lesson 2 activity : Data tansformation - Energy excel file
library(readxl)
energy <- read_excel("Documents/GitHub/DS-Student-Resources/DS104-Data-Wrangling-and-Visualization/LearnDWEg/energy.xlsx")
View(energy)

#To transpose rows in columns
energy_trans <- t(energy)
View(energy_trans)

# convert the matrix format to data set 
energy1 <- as.data.frame(energy_trans)

#Change the column names 

names(energy1) <- gsub("V" , "Year" , names(energy1))
View(energy1)





